import Pricing from './components/marketing/sections/pricing/three_tiers.jsx'
import Pricing1 from './components/marketing/sections/pricing/three_tiers_on_brand_and_feature_comparison.jsx'
import Pricing2 from './components/marketing/sections/pricing/with_comparison_table.jsx'
import Test from './components/Test.jsx'
// import Filter from './'

function App() {

  return (
    <>
      {/* <div className='w-screen min-h-screen flex items-center justify-center'> */}
        {/* <Pricing/> */}
        {/* <Pricing2/> */}
        <Test/>
        {/* <Pricing1/> */}
        {/* <Hai/> */}
        {/* <Testing/> */}
        {/* <OnBoard/> */}
        {/* <About/> */}
        {/* <Select/> */}
        {/* <Faq1/> */}
        {/* <Example1/> */}
        {/* <Example3/> */}
      {/* </div> */}
      {/* <ModalVideo/> */}
      {/* <ModalVideo1/> */}
    </>
  )
}

export default App
